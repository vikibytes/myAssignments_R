/* Node completed recruitment, nothing to do */
